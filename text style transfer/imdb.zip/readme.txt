@InProceedings{dai2019style,
  author          = {Ning Dai and Jianze Liang and  Xipeng Qiu and Xuanjing Huang},
  title           = {Style Transformer: Unpaired Text Style Transfer without Disentangled Latent Representation},
  booktitle       = {Proceedings of the Annual Meeting of the Association for Computational Linguistics},
  year            = {2019},
  url             = {https://arxiv.org/abs/1905.05621},
}