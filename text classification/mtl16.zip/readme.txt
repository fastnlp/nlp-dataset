@InProceedings{liu2017adversarial,
  author          = {Pengfei Liu and Xipeng Qiu and Xuanjing Huang},
  title           = {Adversarial Multi-task Learning for Text Classification},
  booktitle       = {Proceedings of the 55th Annual Meeting of the Association for Computational Linguistics},
  year            = {2017},
  pages           = {1--10},
  url             = {http://aclweb.org/anthology/P/P17/P17-1001.pdf},
}